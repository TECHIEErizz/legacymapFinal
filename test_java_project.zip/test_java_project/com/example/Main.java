package com.example;

public class Main {
    public static void main(String[] args) {
        UserManager userManager = new UserManager();
        userManager.addUser("Alice");
        userManager.addUser("Bob");
    }
}
